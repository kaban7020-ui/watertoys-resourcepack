package com.watertoys.plugin;

import com.watertoys.plugin.vehicles.JetSki;
import com.watertoys.plugin.vehicles.Towable;
import com.watertoys.plugin.vehicles.WaterVehicle;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class VehicleManager {

    private final WaterToysPlugin plugin;
    private final List<WaterVehicle> vehicles = new ArrayList<>();
    private final Map<UUID, Long> emptySince = new HashMap<>();
    private BukkitRunnable task;

    public VehicleManager(WaterToysPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                tickAll();
            }
        };
        task.runTaskTimer(plugin, 1L, 1L);
    }

    public void stop() {
        if (task != null) task.cancel();
        for (WaterVehicle v : new ArrayList<>(vehicles)) {
            v.remove();
        }
        vehicles.clear();
    }

    public void register(WaterVehicle vehicle) {
        vehicles.add(vehicle);
    }

    public void remove(WaterVehicle vehicle) {
        vehicle.remove();
        vehicles.remove(vehicle);
    }

    public List<WaterVehicle> all() {
        return vehicles;
    }

    public WaterVehicle findByBody(Interaction interaction) {
        for (WaterVehicle v : vehicles) {
            if (v.getBody().equals(interaction)) return v;
        }
        return null;
    }

    public WaterVehicle findBySeat(Interaction interaction) {
        for (WaterVehicle v : vehicles) {
            if (v.getSeats().contains(interaction)) return v;
        }
        return null;
    }

    public WaterVehicle findByAnyInteraction(Interaction interaction) {
        WaterVehicle v = findByBody(interaction);
        return v != null ? v : findBySeat(interaction);
    }

    public JetSki findOwnedJetSki(UUID owner) {
        for (WaterVehicle v : vehicles) {
            if (v instanceof JetSki js && v.getOwner().equals(owner)) return js;
        }
        return null;
    }

    public <T extends Towable> T findOwnedTowable(UUID owner, Class<T> type) {
        for (WaterVehicle v : vehicles) {
            if (type.isInstance(v) && v.getOwner().equals(owner)) return type.cast(v);
        }
        return null;
    }

    public JetSki findNearestJetSki(org.bukkit.Location loc, double maxDistance) {
        JetSki best = null;
        double bestDist = maxDistance;
        for (WaterVehicle v : vehicles) {
            if (v instanceof JetSki js) {
                double d = v.getLocation().distance(loc);
                if (d <= bestDist) {
                    best = js;
                    bestDist = d;
                }
            }
        }
        return best;
    }

    private void tickAll() {
        Iterator<WaterVehicle> it = vehicles.iterator();
        long now = System.currentTimeMillis();
        long cleanupMillis = plugin.getConfig().getLong("cleanup.remove-empty-after-seconds", 300) * 1000L;

        while (it.hasNext()) {
            WaterVehicle v = it.next();
            if (!v.isValid()) {
                it.remove();
                continue;
            }
            v.tick();

            boolean empty = !hasAnyRider(v);
            UUID key = v.getBody().getUniqueId();
            if (empty) {
                emptySince.putIfAbsent(key, now);
                if (cleanupMillis > 0 && now - emptySince.get(key) > cleanupMillis) {
                    v.remove();
                    it.remove();
                    emptySince.remove(key);
                }
            } else {
                emptySince.remove(key);
            }
        }
    }

    private boolean hasAnyRider(WaterVehicle v) {
        if (v.getBody().getPassengers().stream().anyMatch(e -> e instanceof Player)) return true;
        for (Interaction seat : v.getSeats()) {
            if (!seat.getPassengers().isEmpty()) return true;
        }
        return false;
    }
}
