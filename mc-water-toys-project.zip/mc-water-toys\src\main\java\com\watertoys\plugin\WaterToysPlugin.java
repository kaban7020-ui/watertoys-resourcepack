package com.watertoys.plugin;

import com.watertoys.plugin.commands.VehicleCommand;
import com.watertoys.plugin.listeners.VehicleListener;
import org.bukkit.plugin.java.JavaPlugin;

public class WaterToysPlugin extends JavaPlugin {

    private VehicleManager vehicleManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        vehicleManager = new VehicleManager(this);
        vehicleManager.start();

        getServer().getPluginManager().registerEvents(new VehicleListener(this), this);

        VehicleCommand vehicleCommand = new VehicleCommand(this);
        getCommand("jetski").setExecutor(vehicleCommand);
        getCommand("jetski").setTabCompleter(vehicleCommand);
        getCommand("banana").setExecutor(vehicleCommand);
        getCommand("banana").setTabCompleter(vehicleCommand);
        getCommand("tube").setExecutor(vehicleCommand);
        getCommand("tube").setTabCompleter(vehicleCommand);

        getLogger().info("WaterToys enabled: jetski/banana/tube ready.");
    }

    @Override
    public void onDisable() {
        if (vehicleManager != null) {
            vehicleManager.stop();
        }
    }

    public VehicleManager getVehicleManager() {
        return vehicleManager;
    }
}
