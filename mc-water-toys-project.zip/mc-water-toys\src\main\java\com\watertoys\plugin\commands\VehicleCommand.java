package com.watertoys.plugin.commands;

import com.watertoys.plugin.VehicleManager;
import com.watertoys.plugin.WaterToysPlugin;
import com.watertoys.plugin.vehicles.Banana;
import com.watertoys.plugin.vehicles.JetSki;
import com.watertoys.plugin.vehicles.Towable;
import com.watertoys.plugin.vehicles.Tube;
import com.watertoys.plugin.vehicles.WaterVehicle;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.List;

public class VehicleCommand implements CommandExecutor, TabCompleter {

    private final WaterToysPlugin plugin;

    public VehicleCommand(WaterToysPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }

        if (args.length < 1) {
            player.sendMessage(err("Использование: /" + label + " <spawn|remove>"));
            return true;
        }

        VehicleManager manager = plugin.getVehicleManager();
        FileConfiguration cfg = plugin.getConfig();
        String sub = args[0].toLowerCase();

        switch (label.toLowerCase()) {
            case "jetski" -> handleJetski(player, manager, cfg, sub);
            case "banana" -> handleBanana(player, manager, cfg, sub);
            case "tube" -> handleTube(player, manager, cfg, sub);
            default -> {}
        }
        return true;
    }

    private void handleJetski(Player player, VehicleManager manager, FileConfiguration cfg, String sub) {
        if (sub.equals("spawn")) {
            JetSki existing = manager.findOwnedJetSki(player.getUniqueId());
            if (existing != null) {
                player.sendMessage(err("У тебя уже есть гидроцикл. Сначала /jetski remove."));
                return;
            }
            Location loc = player.getLocation();
            JetSki jetSki = new JetSki(loc, player.getUniqueId(),
                    cfg.getString("jetski.model-key", "jetski"),
                    Material.valueOf(cfg.getString("jetski.base-item", "LEATHER_HORSE_ARMOR")),
                    cfg.getDouble("jetski.max-speed"),
                    cfg.getDouble("jetski.acceleration"),
                    cfg.getDouble("jetski.friction"),
                    cfg.getDouble("jetski.reverse-speed"),
                    cfg.getDouble("jetski.turn-rate"));
            manager.register(jetSki);
            jetSki.mountDriver(player);
            player.sendMessage(ok("Гидроцикл заспавнен! WASD/стрелки для управления."));
        } else if (sub.equals("remove")) {
            JetSki existing = manager.findOwnedJetSki(player.getUniqueId());
            if (existing == null) {
                player.sendMessage(err("У тебя нет гидроцикла."));
                return;
            }
            manager.remove(existing);
            player.sendMessage(ok("Гидроцикл удалён."));
        } else {
            player.sendMessage(err("Использование: /jetski <spawn|remove>"));
        }
    }

    private void handleBanana(Player player, VehicleManager manager, FileConfiguration cfg, String sub) {
        if (sub.equals("spawn")) {
            Banana existing = manager.findOwnedTowable(player.getUniqueId(), Banana.class);
            if (existing != null) {
                player.sendMessage(err("У тебя уже есть банан. Сначала /banana remove."));
                return;
            }
            Location loc = player.getLocation();
            Banana banana = new Banana(loc, player.getUniqueId(),
                    cfg.getString("banana.model-key", "banana"),
                    Material.valueOf(cfg.getString("banana.base-item", "LEATHER_HORSE_ARMOR")),
                    cfg.getInt("banana.capacity", 6),
                    cfg.getDouble("banana.rope-length"),
                    cfg.getDouble("banana.seat-spacing"),
                    cfg.getDouble("tow.follow-smoothing"),
                    cfg.getBoolean("eject.enabled"),
                    cfg.getDouble("eject.speed-threshold-percent") / 100.0,
                    cfg.getDouble("eject.turn-threshold-degrees"),
                    cfg.getDouble("eject.chance-per-tick"));
            manager.register(banana);
            attachToNearestJetski(player, manager, banana);
            player.sendMessage(ok("Банан заспавнен (6 мест). Правый клик без крада — сесть."));
        } else if (sub.equals("remove")) {
            removeOwnedTowable(player, manager, Banana.class, "банана");
        } else {
            player.sendMessage(err("Использование: /banana <spawn|remove>"));
        }
    }

    private void handleTube(Player player, VehicleManager manager, FileConfiguration cfg, String sub) {
        if (sub.equals("spawn")) {
            Tube existing = manager.findOwnedTowable(player.getUniqueId(), Tube.class);
            if (existing != null) {
                player.sendMessage(err("У тебя уже есть таблетка. Сначала /tube remove."));
                return;
            }
            Location loc = player.getLocation();
            Tube tube = new Tube(loc, player.getUniqueId(),
                    cfg.getString("tube.model-key", "tube"),
                    Material.valueOf(cfg.getString("tube.base-item", "LEATHER_HORSE_ARMOR")),
                    cfg.getInt("tube.capacity", 3),
                    cfg.getDouble("tube.rope-length"),
                    cfg.getDouble("tube.seat-spacing"),
                    cfg.getDouble("tow.follow-smoothing"),
                    cfg.getBoolean("eject.enabled"),
                    cfg.getDouble("eject.speed-threshold-percent") / 100.0,
                    cfg.getDouble("eject.turn-threshold-degrees"),
                    cfg.getDouble("eject.chance-per-tick"));
            manager.register(tube);
            attachToNearestJetski(player, manager, tube);
            player.sendMessage(ok("Таблетка заспавнена (3 места). Правый клик без крада — сесть."));
        } else if (sub.equals("remove")) {
            removeOwnedTowable(player, manager, Tube.class, "таблетки");
        } else {
            player.sendMessage(err("Использование: /tube <spawn|remove>"));
        }
    }

    private <T extends Towable> void removeOwnedTowable(Player player, VehicleManager manager, Class<T> type, String ruName) {
        T existing = manager.findOwnedTowable(player.getUniqueId(), type);
        if (existing == null) {
            player.sendMessage(err("У тебя нет " + ruName + "."));
            return;
        }
        manager.remove(existing);
        player.sendMessage(ok("Убрано: " + ruName + "."));
    }

    private void attachToNearestJetski(Player player, VehicleManager manager, Towable towable) {
        JetSki nearest = manager.findNearestJetSki(player.getLocation(), 10.0);
        if (nearest != null && nearest.getTowing() == null) {
            nearest.setTowing(towable);
            towable.setTowSource(nearest);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("spawn", "remove");
        }
        return List.of();
    }

    private Component ok(String msg) {
        return Component.text(msg).color(NamedTextColor.GREEN);
    }

    private Component err(String msg) {
        return Component.text(msg).color(NamedTextColor.RED);
    }
}
