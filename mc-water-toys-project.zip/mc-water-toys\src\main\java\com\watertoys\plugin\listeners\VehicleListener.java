package com.watertoys.plugin.listeners;

import com.watertoys.plugin.VehicleManager;
import com.watertoys.plugin.WaterToysPlugin;
import com.watertoys.plugin.vehicles.JetSki;
import com.watertoys.plugin.vehicles.Towable;
import com.watertoys.plugin.vehicles.WaterVehicle;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

public class VehicleListener implements Listener {

    private final WaterToysPlugin plugin;

    public VehicleListener(WaterToysPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Interaction interaction)) return;

        VehicleManager manager = plugin.getVehicleManager();
        WaterVehicle vehicle = manager.findByAnyInteraction(interaction);
        if (vehicle == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        if (vehicle instanceof JetSki jetSki) {
            if (jetSki.getBody().equals(interaction)) {
                if (player.isSneaking()) {
                    // sneak-click a jet ski: hook the nearest free towable owned by this player to it
                    Towable owned = findOwnedFreeTowable(manager, player);
                    if (owned != null && jetSki.getTowing() == null) {
                        jetSki.setTowing(owned);
                        owned.setTowSource(jetSki);
                        player.sendMessage(Component.text("Прицепил трос!").color(NamedTextColor.AQUA));
                    }
                } else if (jetSki.mountDriver(player)) {
                    player.sendMessage(Component.text("Сел за руль гидроцикла.").color(NamedTextColor.AQUA));
                }
            }
            return;
        }

        if (vehicle instanceof Towable towable) {
            if (player.isSneaking() && towable.getBody().equals(interaction)) {
                if (towable.getTowSource() != null) {
                    detachFromOwner(manager, towable);
                    towable.setTowSource(null);
                    player.sendMessage(Component.text("Отцепил трос.").color(NamedTextColor.AQUA));
                }
                return;
            }
            if (towable.seatPlayer(player)) {
                player.sendMessage(Component.text("Запрыгнул на борт!").color(NamedTextColor.AQUA));
            } else {
                player.sendMessage(Component.text("Все места заняты.").color(NamedTextColor.RED));
            }
        }
    }

    private void detachFromOwner(VehicleManager manager, Towable towable) {
        JetSki owner = manager.findOwnedJetSki(towable.getOwner());
        if (owner != null && owner.getTowing() == towable) {
            owner.setTowing(null);
        }
    }

    private Towable findOwnedFreeTowable(VehicleManager manager, Player player) {
        for (WaterVehicle v : manager.all()) {
            if (v instanceof Towable t && t.getOwner().equals(player.getUniqueId()) && t.getTowSource() == null) {
                return t;
            }
        }
        return null;
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        VehicleManager manager = plugin.getVehicleManager();
        if (event.getEntity() instanceof Interaction interaction && manager.findByAnyInteraction(interaction) != null) {
            event.setCancelled(true);
        }
    }
}
