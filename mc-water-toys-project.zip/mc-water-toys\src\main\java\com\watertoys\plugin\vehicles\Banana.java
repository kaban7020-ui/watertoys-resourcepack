package com.watertoys.plugin.vehicles;

import org.bukkit.Location;
import org.bukkit.Material;

import java.util.UUID;

public class Banana extends Towable {

    public Banana(Location spawnAt, UUID owner, String modelKey, Material baseItem,
                  int capacity, double ropeLength, double seatSpacing, double followSmoothing,
                  boolean ejectEnabled, double ejectSpeedThresholdFraction, double ejectTurnThresholdDegrees,
                  double ejectChancePerTick) {
        super(spawnAt, owner, buildModelItem(baseItem, modelKey), 2.6f, 0.7f,
                capacity, ropeLength, seatSpacing, followSmoothing,
                ejectEnabled, ejectSpeedThresholdFraction, ejectTurnThresholdDegrees, ejectChancePerTick);
    }
}
