package com.watertoys.plugin.vehicles;

import org.bukkit.Input;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.UUID;

public class JetSki extends WaterVehicle {

    private final double maxSpeed;
    private final double acceleration;
    private final double friction;
    private final double reverseSpeed;
    private final double turnRate;

    private double speed = 0.0;
    private double lastYawDelta = 0.0;

    private Towable towing;

    public JetSki(Location spawnAt, UUID owner, String modelKey, Material baseItem,
                  double maxSpeed, double acceleration, double friction, double reverseSpeed, double turnRate) {
        super(spawnAt, owner, buildModelItem(baseItem, modelKey), 1.3f, 0.9f);
        this.maxSpeed = maxSpeed;
        this.acceleration = acceleration;
        this.friction = friction;
        this.reverseSpeed = reverseSpeed;
        this.turnRate = turnRate;
    }

    public void setTowing(Towable towable) {
        this.towing = towable;
    }

    public Towable getTowing() {
        return towing;
    }

    public boolean mountDriver(Player player) {
        if (body.getPassengers().stream().anyMatch(e -> e instanceof Player)) {
            return false;
        }
        return body.addPassenger(player);
    }

    public double getSpeed() {
        return speed;
    }

    public double getMaxSpeed() {
        return maxSpeed;
    }

    public double getLastYawDelta() {
        return lastYawDelta;
    }

    /** World-space point behind the jet ski where a tow rope attaches. */
    public Location getHitchLocation() {
        Vector fwd = new Vector(forwardVector(yaw).x(), 0, forwardVector(yaw).z());
        return body.getLocation().clone().subtract(fwd.multiply(1.1));
    }

    @Override
    public void tick() {
        List<Entity> passengers = body.getPassengers();
        Player driver = null;
        for (Entity e : passengers) {
            if (e instanceof Player p) {
                driver = p;
                break;
            }
        }

        double turnInput = 0;
        boolean forwardHeld = false;
        boolean backwardHeld = false;

        if (driver != null) {
            Input input = driver.getCurrentInput();
            if (input.isForward()) forwardHeld = true;
            if (input.isBackward()) backwardHeld = true;
            if (input.isLeft()) turnInput -= 1;
            if (input.isRight()) turnInput += 1;
        }

        if (forwardHeld) {
            speed = Math.min(maxSpeed, speed + acceleration);
        } else if (backwardHeld) {
            speed = Math.max(-reverseSpeed, speed - acceleration);
        } else {
            if (speed > 0) speed = Math.max(0, speed - friction);
            else if (speed < 0) speed = Math.min(0, speed + friction);
        }

        double yawDelta = 0;
        if (Math.abs(speed) > 0.02) {
            yawDelta = turnInput * turnRate * (speed < 0 ? -1 : 1);
        }
        lastYawDelta = yawDelta;

        double newYaw = yaw + yawDelta;
        Location current = body.getLocation();
        Block feet = current.getBlock();
        boolean inWater = feet.getType() == Material.WATER || feet.getRelative(0, -1, 0).getType() == Material.WATER;

        if (!inWater) {
            // beached: kill speed fast so it doesn't sail across land
            speed *= 0.5;
        }

        var fwd = forwardVector(newYaw);
        Vector velocity = new Vector(fwd.x(), 0, fwd.z()).multiply(speed);

        Location next = current.clone().add(velocity);
        next.setY(surfaceY(next));
        next.setYaw((float) newYaw);

        updateYaw(newYaw);
        body.teleport(next);
        display.teleport(next);

        if (towing != null && towing.isValid()) {
            towing.setTowSource(this);
        }
    }

    private double surfaceY(Location at) {
        Block block = at.getBlock();
        if (block.getType() == Material.WATER) {
            return block.getY() + 0.85;
        }
        Block below = block.getRelative(0, -1, 0);
        if (below.getType() == Material.WATER) {
            return below.getY() + 0.85;
        }
        return at.getY();
    }
}
