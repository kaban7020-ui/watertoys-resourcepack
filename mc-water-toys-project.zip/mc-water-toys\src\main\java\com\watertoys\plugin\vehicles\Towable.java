package com.watertoys.plugin.vehicles;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/** A towed water toy (banana boat / tube) with several seats spread along its length. */
public abstract class Towable extends WaterVehicle {

    private static final Random RANDOM = new Random();

    private final List<Interaction> seats = new ArrayList<>();
    private final double ropeLength;
    private final double seatSpacing;
    private final double followSmoothing;

    private final boolean ejectEnabled;
    private final double ejectSpeedThresholdFraction;
    private final double ejectTurnThresholdDegrees;
    private final double ejectChancePerTick;

    private JetSki towSource;

    protected Towable(Location spawnAt, UUID owner, ItemStack modelItem, float hitboxWidth, float hitboxHeight,
                       int capacity, double ropeLength, double seatSpacing, double followSmoothing,
                       boolean ejectEnabled, double ejectSpeedThresholdFraction, double ejectTurnThresholdDegrees,
                       double ejectChancePerTick) {
        super(spawnAt, owner, modelItem, hitboxWidth, hitboxHeight);
        this.ropeLength = ropeLength;
        this.seatSpacing = seatSpacing;
        this.followSmoothing = followSmoothing;
        this.ejectEnabled = ejectEnabled;
        this.ejectSpeedThresholdFraction = ejectSpeedThresholdFraction;
        this.ejectTurnThresholdDegrees = ejectTurnThresholdDegrees;
        this.ejectChancePerTick = ejectChancePerTick;

        for (int i = 0; i < capacity; i++) {
            Interaction seat = spawnAt.getWorld().spawn(spawnAt, Interaction.class, s -> {
                s.setInteractionWidth(0.8f);
                s.setInteractionHeight(0.6f);
                s.setResponsive(true);
                s.setPersistent(true);
            });
            seats.add(seat);
        }
    }

    @Override
    public List<Interaction> getSeats() {
        return seats;
    }

    public void setTowSource(JetSki source) {
        this.towSource = source;
    }

    public JetSki getTowSource() {
        return towSource;
    }

    public boolean seatPlayer(Player player) {
        for (Interaction seat : seats) {
            if (seat.getPassengers().isEmpty()) {
                return seat.addPassenger(player);
            }
        }
        return false;
    }

    @Override
    public void tick() {
        Location current = body.getLocation();

        if (towSource != null && towSource.isValid()) {
            Vector3f fwd = forwardVector(towSource.getYaw());
            Location hitch = towSource.getHitchLocation();
            Location target = hitch.clone().subtract(new Vector(fwd.x(), 0, fwd.z()).multiply(ropeLength));
            target.setY(surfaceY(target));

            Location smoothed = current.clone().add(target.clone().subtract(current).multiply(followSmoothing));

            double dx = smoothed.getX() - current.getX();
            double dz = smoothed.getZ() - current.getZ();
            double newYaw = yaw;
            if (dx * dx + dz * dz > 0.0004) {
                newYaw = Math.toDegrees(Math.atan2(-dx, dz));
            }

            smoothed.setYaw((float) newYaw);
            updateYaw(newYaw);
            body.teleport(smoothed);
            display.teleport(smoothed);

            maybeEject(towSource);
        } else {
            // drifting untethered: gentle bobbing, no active movement
            Location settled = current.clone();
            settled.setY(surfaceY(current));
            if (Math.abs(settled.getY() - current.getY()) > 0.01) {
                body.teleport(settled);
            }
        }

        syncSeats();
    }

    private void maybeEject(JetSki source) {
        if (!ejectEnabled) return;
        boolean fastEnough = Math.abs(source.getSpeed()) >= source.getMaxSpeed() * ejectSpeedThresholdFraction;
        boolean sharpTurn = Math.abs(source.getLastYawDelta()) >= ejectTurnThresholdDegrees;
        if (!(fastEnough && sharpTurn)) return;

        for (Interaction seat : seats) {
            if (seat.getPassengers().isEmpty()) continue;
            if (RANDOM.nextDouble() < ejectChancePerTick) {
                Entity rider = seat.getPassengers().get(0);
                seat.removePassenger(rider);
                Vector kick = new Vector(RANDOM.nextDouble() - 0.5, 0.35, RANDOM.nextDouble() - 0.5).multiply(0.6);
                rider.setVelocity(kick);
            }
        }
    }

    private void syncSeats() {
        Location base = body.getLocation();
        Vector3f fwd = forwardVector(yaw);
        Vector3f right = new Vector3f(fwd.z(), 0, -fwd.x());

        double totalWidth = (seats.size() - 1) * seatSpacing;
        for (int i = 0; i < seats.size(); i++) {
            double localOffset = -totalWidth / 2.0 + i * seatSpacing;
            Location seatLoc = base.clone().add(right.x() * localOffset, 0.4, right.z() * localOffset);
            seatLoc.setYaw((float) yaw);
            Interaction seat = seats.get(i);
            seat.teleport(seatLoc);
        }
    }

    private double surfaceY(Location at) {
        Block block = at.getBlock();
        if (block.getType() == Material.WATER) {
            return block.getY() + 0.7;
        }
        Block below = block.getRelative(0, -1, 0);
        if (below.getType() == Material.WATER) {
            return below.getY() + 0.7;
        }
        return at.getY();
    }
}
