package com.watertoys.plugin.vehicles;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Display;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import java.util.UUID;

/**
 * Base for a rideable/visible water toy: an invisible Interaction entity used as the
 * physical body + click target, with an ItemDisplay riding it to show the custom model.
 */
public abstract class WaterVehicle {

    protected final Interaction body;
    protected final ItemDisplay display;
    protected final UUID owner;

    protected double yaw; // degrees, our own tracked heading (independent of entity yaw quirks)

    protected WaterVehicle(Location spawnAt, UUID owner, ItemStack modelItem, float hitboxWidth, float hitboxHeight) {
        this.owner = owner;
        this.yaw = spawnAt.getYaw();

        this.body = spawnAt.getWorld().spawn(spawnAt, Interaction.class, i -> {
            i.setInteractionWidth(hitboxWidth);
            i.setInteractionHeight(hitboxHeight);
            i.setResponsive(true);
            i.setPersistent(true);
        });

        this.display = spawnAt.getWorld().spawn(spawnAt, ItemDisplay.class, d -> {
            d.setItemStack(modelItem);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            d.setPersistent(true);
            d.setBillboard(Display.Billboard.FIXED);
        });
        this.body.addPassenger(this.display);
    }

    public Interaction getBody() {
        return body;
    }

    public ItemDisplay getDisplay() {
        return display;
    }

    public UUID getOwner() {
        return owner;
    }

    public Location getLocation() {
        return body.getLocation();
    }

    public double getYaw() {
        return yaw;
    }

    public List<Interaction> getSeats() {
        return java.util.Collections.emptyList();
    }

    /** Updates our tracked heading and the display's rotation. Does NOT move the entities;
     *  the caller is responsible for teleporting body/display to their new Location
     *  (with that Location's yaw already set to yawDegrees) afterwards. */
    protected void updateYaw(double yawDegrees) {
        this.yaw = yawDegrees;
        float radians = (float) Math.toRadians(-yawDegrees);
        Transformation t = display.getTransformation();
        display.setTransformation(new Transformation(
                t.getTranslation(),
                new Quaternionf().rotateY(radians),
                t.getScale(),
                t.getRightRotation()));
    }

    /** Builds an item whose visual model is selected via the resource pack's
     *  minecraft:select/minecraft:custom_model_data "when" case matching modelKey. */
    protected static ItemStack buildModelItem(Material baseItem, String modelKey) {
        ItemStack item = new ItemStack(baseItem);
        ItemMeta meta = item.getItemMeta();
        CustomModelDataComponent component = meta.getCustomModelDataComponent();
        component.setStrings(List.of(modelKey));
        meta.setCustomModelDataComponent(component);
        item.setItemMeta(meta);
        return item;
    }

    protected static Vector3f forwardVector(double yawDegrees) {
        double rad = Math.toRadians(yawDegrees);
        return new Vector3f((float) -Math.sin(rad), 0f, (float) Math.cos(rad));
    }

    /** Called once per server tick by the manager. */
    public abstract void tick();

    public void remove() {
        for (Interaction seat : getSeats()) {
            if (seat != null) {
                seat.eject();
                seat.remove();
            }
        }
        body.eject();
        display.remove();
        body.remove();
    }

    public boolean isValid() {
        return body.isValid() && display.isValid();
    }
}
